.onAttach <- function(libname, pkgname) {
  packageStartupMessage(
    "KWELA 1.0.0 loaded successfully\n",
    "  Architecture: 6-Layer Hierarchical Adaptive Classification\n",
    "  Main: kwela_analyze(), kwela_summarize(), kwela_diagnostics()\n",
    "  Plate: kwela_plate_normalize(), kwela_bootstrap_summary()\n",
    "  Profiles: standard, sensitive, matrix_robust, auto\n",
    "  Modes: diagnostic (default), research\n",
    "  Instability: compute_instability_flags()\n",
    "  Group-aware mixed-assay support (RT-QuIC + Nano-QuIC)"
  )
}
